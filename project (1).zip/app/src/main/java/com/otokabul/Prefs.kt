package com.otokabul

import android.content.Context
import android.content.SharedPreferences

class Leg(val min: Int, val dist: String)
class Job(val ts: Long, val price: Int, val pMin: Int, val pDist: String, val tMin: Int, val tDist: String)

object Prefs {
    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("p", Context.MODE_PRIVATE)
    fun minPrice(c: Context) = sp(c).getInt("min", 250)
    fun setMinPrice(c: Context, v: Int) = sp(c).edit().putInt("min", v).apply()
    fun delay(c: Context) = sp(c).getLong("delay", 300L)
    fun setDelay(c: Context, v: Long) = sp(c).edit().putLong("delay", v).apply()
    fun active(c: Context) = sp(c).getBoolean("active", false)
    fun setActive(c: Context, v: Boolean) = sp(c).edit().putBoolean("active", v).apply()
    fun overlay(c: Context) = sp(c).getBoolean("overlay", false)
    fun setOverlay(c: Context, v: Boolean) = sp(c).edit().putBoolean("overlay", v).apply()
    fun key(c: Context) = sp(c).getString("key", "") ?: ""
    fun count(c: Context) = sp(c).getInt("count", 0)
    fun sum(c: Context) = sp(c).getInt("sum", 0)

    private fun lines(c: Context) = (sp(c).getString("jobs", "") ?: "").split(";").filter { it.contains("|") }

    fun jobs(c: Context): List<Job> = lines(c).mapNotNull {
        val a = it.split("|")
        if (a.size < 6) null else Job(a[0].toLong(), a[1].toInt(), a[2].toInt(), a[3], a[4].toInt(), a[5])
    }

    // Listede en fazla 10 kayıt tutulur, 11. gelince en eski silinir
    fun addJob(c: Context, price: Int, p: Leg?, t: Leg?) {
        val line = "${System.currentTimeMillis()}|$price|${p?.min ?: -1}|${p?.dist ?: ""}|${t?.min ?: -1}|${t?.dist ?: ""}"
        val list = (lines(c) + line).takeLast(10)
        sp(c).edit().putString("jobs", list.joinToString(";") + ";")
            .putInt("count", count(c) + 1).putInt("sum", sum(c) + price).apply()
    }

    fun clearJobs(c: Context) = sp(c).edit().putString("jobs", "").putInt("count", 0).putInt("sum", 0).apply()
}
