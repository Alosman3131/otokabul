package com.otokabul

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("p", Context.MODE_PRIVATE)
    fun minPrice(c: Context) = sp(c).getInt("min", 250)
    fun setMinPrice(c: Context, v: Int) = sp(c).edit().putInt("min", v).apply()
    fun delay(c: Context) = sp(c).getLong("delay", 300L)
    fun setDelay(c: Context, v: Long) = sp(c).edit().putLong("delay", v).apply()
    fun active(c: Context) = sp(c).getBoolean("active", false)
    fun setActive(c: Context, v: Boolean) = sp(c).edit().putBoolean("active", v).apply()
    fun overlay(c: Context) = sp(c).getBoolean("overlay", false)
    fun setOverlay(c: Context, v: Boolean) = sp(c).edit().putBoolean("overlay", v).apply()

    fun jobs(c: Context): List<Pair<Long, Int>> =
        (sp(c).getString("jobs", "") ?: "").split(";").filter { it.contains("|") }.map {
            val a = it.split("|"); Pair(a[0].toLong(), a[1].toInt())
        }

    fun addJob(c: Context, price: Int) {
        val old = sp(c).getString("jobs", "") ?: ""
        sp(c).edit().putString("jobs", old + "${System.currentTimeMillis()}|$price;").apply()
    }

    fun clearJobs(c: Context) = sp(c).edit().putString("jobs", "").apply()
}
