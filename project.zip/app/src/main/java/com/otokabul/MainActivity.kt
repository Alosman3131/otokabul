package com.otokabul

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var summary: TextView
    private lateinit var list: TextView
    private lateinit var swActive: Switch
    private lateinit var swOverlay: Switch

    private fun EditText.onChange(f: (String) -> Unit) {
        addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { f(s.toString()) }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        fun label(t: String) = TextView(this).apply { text = t; textSize = 14f; setPadding(0, pad, 0, 0) }

        root.addView(TextView(this).apply { text = "Oto Kabul"; textSize = 26f })
        status = TextView(this); root.addView(status)
        root.addView(Button(this).apply {
            text = "Erişilebilirlik ayarlarını aç"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        root.addView(label("En az kabul edilecek tutar (₺, soldaki rakam)"))
        root.addView(EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(Prefs.minPrice(this@MainActivity).toString())
            onChange { Prefs.setMinPrice(this@MainActivity, it.toIntOrNull() ?: 0) }
        })
        root.addView(label("Kabul etmeden önce bekleme (ms)"))
        root.addView(EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(Prefs.delay(this@MainActivity).toString())
            onChange { Prefs.setDelay(this@MainActivity, it.toLongOrNull() ?: 0L) }
        })

        swActive = Switch(this).apply {
            text = "Otomatik kabul"; setPadding(0, pad, 0, 0)
            setOnCheckedChangeListener { _, v -> Prefs.setActive(this@MainActivity, v) }
        }
        root.addView(swActive)
        swOverlay = Switch(this).apply {
            text = "Ekranda ON/OFF butonu (overlay)"; setPadding(0, pad, 0, 0)
            setOnCheckedChangeListener { _, v -> Prefs.setOverlay(this@MainActivity, v) }
        }
        root.addView(swOverlay)

        root.addView(label("Alınan işler"))
        summary = TextView(this).apply { textSize = 18f }
        root.addView(summary)
        list = TextView(this); root.addView(list)
        root.addView(Button(this).apply {
            text = "Kayıtları sıfırla"
            setOnClickListener { Prefs.clearJobs(this@MainActivity); refresh() }
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val en = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true
        status.text = if (en) "Erişilebilirlik: AÇIK ✅" else "Erişilebilirlik: KAPALI ❌ (Yüklü uygulamalar > Oto Kabul'ü aç)"
        swActive.isChecked = Prefs.active(this)
        swOverlay.isChecked = Prefs.overlay(this)
        val jobs = Prefs.jobs(this)
        summary.text = "${jobs.size} iş alındı, toplam ₺${jobs.sumOf { it.second }}"
        val f = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
        list.text = jobs.reversed().take(50).joinToString("\n") { "${f.format(Date(it.first))}  ₺${it.second}" }
    }
}
